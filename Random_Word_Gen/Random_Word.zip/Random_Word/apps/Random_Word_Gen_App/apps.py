from django.apps import AppConfig


class RandomWordGenAppConfig(AppConfig):
    name = 'Random_Word_Gen_App'
